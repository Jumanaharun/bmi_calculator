import 'package:bmi_calc/result_page.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  double height = 0.0; // Height in meters
  double weight = 0.0; // Weight in kilograms

  void calculateAndNavigate() {
    if (height > 0 && weight > 0) {
      double bmi = weight / (height * height);
      String bmiResult = bmi.toStringAsFixed(2);

      // Navigate to the ResultPage and pass the BMI result
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ResultPage(result: bmiResult),
        ),
      );
    } else {
      // Show an error message if inputs are invalid
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter valid height and weight")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("BMI Calculator"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              decoration: const InputDecoration(
                labelText: "Height (m)",
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                height = double.tryParse(value) ?? 0.0;
              },
            ),
            const SizedBox(height: 10.0),
            TextField(
              decoration: const InputDecoration(
                labelText: "Weight (kg)",
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                weight = double.tryParse(value) ?? 0.0;
              },
            ),
            const SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: calculateAndNavigate,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(
                    vertical: 15.0, horizontal: 50.0),
              ),
              child: const Text(
                "Calculate",
                style: TextStyle(fontSize: 18.0),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
